/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dictonary.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arajapak <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/05 14:07:32 by arajapak          #+#    #+#             */
/*   Updated: 2024/10/05 14:09:34 by arajapak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>
#define MAX_ENTER 100

void	keyValue(char a char b)
(
 	char	a;
	char	b;

	a = key;
	b = value;

	
