/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arajapak <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/03 10:39:01 by arajapak          #+#    #+#             */
/*   Updated: 2024/10/08 11:22:30 by arajapak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 32 || str[i] > 126)
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
int	main(void)
{
	int	result;

	result = ft_str_is_printable("abcd");
	printf("%d\n", result);
	result = ft_str_is_printable("ACVM");
	printf("%d\n", result);
	result = ft_str_is_printable("%");
	printf("%d\n", result);
	result = ft_str_is_printable("  ");
	printf("%d\n", result);
	return (0);
}*/
