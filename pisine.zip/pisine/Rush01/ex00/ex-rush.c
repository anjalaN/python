#include <stdio.h>
#include <stdlibo.h>

void	box(int n)
{
	int a[
	
	



}
int main()
{
	return (0);
}
