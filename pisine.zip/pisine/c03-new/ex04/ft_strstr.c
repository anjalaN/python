/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arajapak <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/09 14:35:32 by arajapak          #+#    #+#             */
/*   Updated: 2024/10/09 16:58:48 by arajapak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	while (str[i] != '\0' && str[i] == to_find[i])
	{
		j = i + 1;
		while (to_find[j] != '\0' && str[j] == to_find[j])
			j++;
		if (to_find[j] == '\0')
			return (&str[i]);
		i++;
	}
	return (NULL);
}
/*
int	main (void)
{
	char	str[] = "finf charactor";
	char	to_find[] = "cha";
	char*	p;
		
	p = strstr(str, to_find);
//	ft_strstr(str, to_find);
	printf("%s\n", p);
	return (0);
}
*/
