/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft-strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arajapak <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/09 13:12:25 by arajapak          #+#    #+#             */
/*   Updated: 2024/10/10 13:34:40 by arajapak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while ((s1[i] != '\0' && s2[i] == s1[i]) && (i < n))
		i++;
	if (i == n)
		return (0);
	return (s1[i] - s2[i]);
}
/*
int	main(void)

{
	char	s1[33] = "my friends hello";
	char	s2[33] = "myto";
	char	result;

	result = ft_strncmp(s1, s2, 2);
	printf("%d\n", result);
	return (0);
}*/
