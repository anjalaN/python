find . -type f | wc -l
