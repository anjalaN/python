basename -s ".sh" $(find . -type f -name "*.sh")

