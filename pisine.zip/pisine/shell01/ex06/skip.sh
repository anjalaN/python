
ls -lt | sed -